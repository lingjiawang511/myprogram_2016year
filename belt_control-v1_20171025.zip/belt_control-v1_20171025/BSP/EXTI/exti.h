#ifndef __EXTI_H
#define __EXIT_H	 

 	 
void EXTIX_Init(void);//�ⲿ�жϳ�ʼ��		 					    
#endif

