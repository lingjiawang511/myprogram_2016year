#ifndef __TIM_H
#define __TIM_H
#include "stm32f10x.h"

void TIM2_Config(void );
void TIM3_Config(void );
void TIM4_Config(void);
#endif
